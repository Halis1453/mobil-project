package com.example.budgeto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
